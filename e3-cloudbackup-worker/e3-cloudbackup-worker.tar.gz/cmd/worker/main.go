package main

import (
	"context"
	"flag"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/your-org/e3-cloudbackup-worker/internal/config"
	"github.com/your-org/e3-cloudbackup-worker/internal/db"
	"github.com/your-org/e3-cloudbackup-worker/internal/jobs"
)

func main() {
	var configPath string
	flag.StringVar(&configPath, "config", "/opt/e3-cloudbackup-worker/config/config.yaml", "Path to config.yaml")
	flag.Parse()

	cfg, err := config.Load(configPath)
	if err != nil {
		log.Fatalf("failed to load config: %v", err)
	}

	dbc, err := db.NewDatabase(cfg)
	if err != nil {
		log.Fatalf("failed to initialize database: %v", err)
	}
	defer dbc.Close()

	// Honor graceful shutdown
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		s := <-sigCh
		log.Printf("received signal %s, shutting down...", s)
		cancel()
	}()

	scheduler := jobs.NewScheduler(dbc, cfg)
	log.Printf("worker starting on host=%s poll_interval=%s max_concurrent=%d",
		cfg.Worker.Hostname, time.Duration(cfg.Worker.PollIntervalSeconds)*time.Second, cfg.Worker.MaxConcurrentJobs)
	if err := scheduler.Run(ctx); err != nil && err != context.Canceled {
		log.Fatalf("scheduler exited with error: %v", err)
	}
	log.Println("worker stopped")
}


