package db

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	_ "github.com/go-sql-driver/mysql"
	"github.com/your-org/e3-cloudbackup-worker/internal/config"
)

type Database struct {
	sqlDB      *sql.DB
	workerHost string
}

func NewDatabase(cfg *config.Config) (*Database, error) {
	db, err := sql.Open("mysql", cfg.MySQLDSN())
	if err != nil {
		return nil, fmt.Errorf("open mysql: %w", err)
	}
	if cfg.Database.MaxConnections > 0 {
		db.SetMaxOpenConns(cfg.Database.MaxConnections)
	}
	if cfg.Database.MaxIdleConnections > 0 {
		db.SetMaxIdleConns(cfg.Database.MaxIdleConnections)
	}
	db.SetConnMaxLifetime(2 * time.Hour)
	return &Database{
		sqlDB:      db,
		workerHost: cfg.Worker.Hostname,
	}, nil
}

func (d *Database) Close() error {
	return d.sqlDB.Close()
}

type Run struct {
	ID    int64
	JobID int64
}

type Job struct {
	ID                int64
	ClientID          int64
	S3UserID          int64
	Name              string
	SourceType        string
	SourceDisplayName string
	SourceConfigEnc   string
	SourcePath        string
	DestBucketID      int64
	DestBucketName    string
	DestPrefix        string
	BackupMode        string
	ValidationMode    string
	// Destination credentials (encrypted)
	DestAccessKeyEnc string
	DestSecretKeyEnc string
}

type Progress struct {
	ProgressPct        float64
	BytesTotal         int64
	BytesTransferred   int64
	ObjectsTotal       int64
	ObjectsTransferred int64
	SpeedBytesPerSec   int64
	EtaSeconds         int64
	CurrentItem        string
}

func (d *Database) GetNextQueuedRuns(ctx context.Context, limit int) ([]Run, error) {
	rows, err := d.sqlDB.QueryContext(ctx, `
		SELECT r.id, r.job_id
		FROM s3_cloudbackup_runs r
		INNER JOIN s3_cloudbackup_jobs j ON j.id = r.job_id
		WHERE r.status = 'queued' AND j.status = 'active'
		ORDER BY r.id ASC
		LIMIT ?`, limit)
	if err != nil {
		return nil, fmt.Errorf("query next queued runs: %w", err)
	}
	defer rows.Close()
	var res []Run
	for rows.Next() {
		var r Run
		if err := rows.Scan(&r.ID, &r.JobID); err != nil {
			return nil, fmt.Errorf("scan run: %w", err)
		}
		res = append(res, r)
	}
	return res, rows.Err()
}

func (d *Database) UpdateRunStatus(ctx context.Context, runID int64, status string, startedAt, finishedAt *time.Time, errorSummary string) error {
	// Build dynamic parts for timestamps
	query := `UPDATE s3_cloudbackup_runs SET status=?, worker_host=?, error_summary=?`
	var args []any
	args = append(args, status, d.workerHost, nullify(errorSummary))
	if startedAt != nil {
		query += `, started_at=?`
		args = append(args, *startedAt)
	}
	if finishedAt != nil {
		query += `, finished_at=?`
		args = append(args, *finishedAt)
	}
	query += ` WHERE id=?`
	args = append(args, runID)

	_, err := d.sqlDB.ExecContext(ctx, query, args...)
	if err != nil {
		return fmt.Errorf("update run status: %w", err)
	}
	return nil
}

func (d *Database) UpdateRunProgress(ctx context.Context, runID int64, p Progress) error {
	_, err := d.sqlDB.ExecContext(ctx, `
		UPDATE s3_cloudbackup_runs
		SET progress_pct=?,
		    bytes_total=?,
		    bytes_transferred=?,
		    objects_total=?,
		    objects_transferred=?,
		    speed_bytes_per_sec=?,
		    eta_seconds=?,
		    current_item=?
		WHERE id=?`,
		p.ProgressPct,
		p.BytesTotal,
		p.BytesTransferred,
		p.ObjectsTotal,
		p.ObjectsTransferred,
		p.SpeedBytesPerSec,
		p.EtaSeconds,
		p.CurrentItem,
		runID,
	)
	if err != nil {
		return fmt.Errorf("update run progress: %w", err)
	}
	return nil
}

func (d *Database) MarkRunCancelled(ctx context.Context, runID int64, reason string) error {
	now := time.Now().UTC()
	return d.UpdateRunStatus(ctx, runID, "cancelled", nil, &now, reason)
}

func (d *Database) GetJobConfig(ctx context.Context, jobID int64) (*Job, error) {
	row := d.sqlDB.QueryRowContext(ctx, `
		SELECT j.id, j.client_id, j.s3_user_id, j.name, j.source_type, j.source_display_name,
		       j.source_config_enc, j.source_path, j.dest_bucket_id, b.name AS dest_bucket_name,
		       j.dest_prefix, j.backup_mode,
		       COALESCE(r.validation_mode, 'none') AS validation_mode,
		       ak.access_key AS dest_access_key_enc,
		       ak.secret_key AS dest_secret_key_enc
		FROM s3_cloudbackup_jobs j
		INNER JOIN s3_buckets b ON b.id = j.dest_bucket_id
		INNER JOIN s3_user_access_keys ak ON ak.user_id = j.s3_user_id
		LEFT JOIN (
			SELECT job_id, MAX(validation_mode) AS validation_mode
			FROM s3_cloudbackup_runs
			WHERE job_id = ?
			GROUP BY job_id
		) r ON r.job_id = j.id
		WHERE j.id = ?`,
		jobID, jobID,
	)
	var j Job
	err := row.Scan(
		&j.ID, &j.ClientID, &j.S3UserID, &j.Name, &j.SourceType, &j.SourceDisplayName,
		&j.SourceConfigEnc, &j.SourcePath, &j.DestBucketID, &j.DestBucketName,
		&j.DestPrefix, &j.BackupMode, &j.ValidationMode,
		&j.DestAccessKeyEnc, &j.DestSecretKeyEnc,
	)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, fmt.Errorf("job %d not found", jobID)
		}
		return nil, fmt.Errorf("scan job: %w", err)
	}
	return &j, nil
}

func (d *Database) CheckCancelRequested(ctx context.Context, runID int64) (bool, error) {
	var flag bool
	err := d.sqlDB.QueryRowContext(ctx, `
		SELECT COALESCE(cancel_requested, 0) FROM s3_cloudbackup_runs WHERE id=?`, runID).
		Scan(&flag)
	if err != nil {
		return false, fmt.Errorf("query cancel flag: %w", err)
	}
	return flag, nil
}

func (d *Database) UpdateRunLogPathAndExcerpt(ctx context.Context, runID int64, logPath, logExcerpt string) error {
	_, err := d.sqlDB.ExecContext(ctx, `
		UPDATE s3_cloudbackup_runs
		SET log_path=?, log_excerpt=?
		WHERE id=?`,
		logPath, logExcerpt, runID,
	)
	if err != nil {
		return fmt.Errorf("update run log info: %w", err)
	}
	return nil
}

func nullify(s string) any {
	if s == "" {
		return nil
	}
	return s
}


