package rclone

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/your-org/e3-cloudbackup-worker/internal/config"
	"github.com/your-org/e3-cloudbackup-worker/internal/db"
)

type Builder struct {
	cfg *config.Config
}

func NewBuilder(cfg *config.Config) *Builder {
	return &Builder{cfg: cfg}
}

// GenerateRcloneConfig writes a minimal rclone config file with:
// - source remote based on job.SourceType and decrypted source_config_enc
// - dest remote for e3 destination with decrypted credentials
// Returns the remote names to use ("source", "dest").
func (b *Builder) GenerateRcloneConfig(ctx context.Context, job *db.Job, configPath string, decryptedSourceJSON string, destAccessKey string, destSecretKey string) (string, string, error) {
	content := new(strings.Builder)
	// Source remote
	switch job.SourceType {
	case "s3_compatible":
		var src S3Source
		if err := json.Unmarshal([]byte(decryptedSourceJSON), &src); err != nil {
			return "", "", fmt.Errorf("parse decrypted source json: %w", err)
		}
		if src.Endpoint == "" || src.AccessKey == "" || src.SecretKey == "" || src.Region == "" {
			return "", "", errors.New("missing required s3 source fields")
		}
		fmt.Fprintf(content, "[source]\n")
		fmt.Fprintf(content, "type = s3\n")
		fmt.Fprintf(content, "provider = Other\n")
		fmt.Fprintf(content, "env_auth = false\n")
		fmt.Fprintf(content, "access_key_id = %s\n", src.AccessKey)
		fmt.Fprintf(content, "secret_access_key = %s\n", src.SecretKey)
		fmt.Fprintf(content, "endpoint = %s\n", src.Endpoint)
		fmt.Fprintf(content, "region = %s\n", src.Region)
		fmt.Fprintln(content)
	case "sftp":
		var s SFTPSource
		if err := json.Unmarshal([]byte(decryptedSourceJSON), &s); err != nil {
			return "", "", fmt.Errorf("parse decrypted source json: %w", err)
		}
		if s.Host == "" || s.User == "" {
			return "", "", errors.New("missing required sftp source fields")
		}
		fmt.Fprintf(content, "[source]\n")
		fmt.Fprintf(content, "type = sftp\n")
		fmt.Fprintf(content, "host = %s\n", s.Host)
		if s.Port > 0 {
			fmt.Fprintf(content, "port = %d\n", s.Port)
		}
		fmt.Fprintf(content, "user = %s\n", s.User)
		if s.Pass != "" {
			fmt.Fprintf(content, "pass = %s\n", s.Pass)
		}
		fmt.Fprintln(content)
	default:
		return "", "", fmt.Errorf("unsupported source type: %s", job.SourceType)
	}
	// Destination remote (e3 / S3-compatible)
	fmt.Fprintf(content, "[dest]\n")
	fmt.Fprintf(content, "type = s3\n")
	fmt.Fprintf(content, "provider = Other\n")
	fmt.Fprintf(content, "env_auth = false\n")
	fmt.Fprintf(content, "access_key_id = %s\n", destAccessKey)
	fmt.Fprintf(content, "secret_access_key = %s\n", destSecretKey)
	fmt.Fprintf(content, "endpoint = %s\n", b.cfg.Destination.Endpoint)
	if b.cfg.Destination.Region != "" {
		fmt.Fprintf(content, "region = %s\n", b.cfg.Destination.Region)
	}
	fmt.Fprintln(content)

	if err := os.MkdirAll(filepath.Dir(configPath), 0o755); err != nil {
		return "", "", fmt.Errorf("ensure config dir: %w", err)
	}
	if err := os.WriteFile(configPath, []byte(content.String()), 0o600); err != nil {
		return "", "", fmt.Errorf("write rclone config: %w", err)
	}
	return "source", "dest", nil
}

// BuildSyncArgs builds arguments for `rclone sync` using prepared remotes.
// It returns the args slice that should be passed to exec.Command(rclone, args...).
func (b *Builder) BuildSyncArgs(job *db.Job, sourceRemote string, destRemote string, configPath string, logPath string) []string {
	sourcePath := job.SourcePath
	if strings.HasPrefix(sourcePath, "/") {
		sourcePath = strings.TrimPrefix(sourcePath, "/")
	}
	dest := fmt.Sprintf("%s:%s/%s", destRemote, job.DestBucketName, strings.TrimPrefix(job.DestPrefix, "/"))
	source := fmt.Sprintf("%s:%s", sourceRemote, sourcePath)

	args := []string{
		"sync",
		source,
		dest,
		"--config", configPath,
		"--use-json-log",
		"--log-file", logPath,
		"--stats", b.cfg.Rclone.StatsInterval,
		"--stats-one-line=false",
	}
	// Global bandwidth limit
	if b.cfg.Worker.MaxBandwidthKbps > 0 {
		args = append(args, "--bwlimit", fmt.Sprintf("%dk", b.cfg.Worker.MaxBandwidthKbps))
	}
	// Log level mapping
	level := strings.ToLower(b.cfg.Rclone.LogLevel)
	if level == "" {
		level = "INFO"
	}
	args = append(args, "--log-level", level)

	return args
}

type S3Source struct {
	Endpoint string `json:"endpoint"`
	AccessKey string `json:"access_key"`
	SecretKey string `json:"secret_key"`
	Bucket   string `json:"bucket"`
	Region   string `json:"region"`
}

type SFTPSource struct {
	Host string `json:"host"`
	Port int    `json:"port"`
	User string `json:"user"`
	Pass string `json:"pass"`
}


