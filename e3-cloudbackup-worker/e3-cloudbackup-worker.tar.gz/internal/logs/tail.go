package logs

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/hpcloud/tail"
)

type ProgressUpdate struct {
	ProgressPct        float64
	BytesTransferred   int64
	BytesTotal         int64
	ObjectsTransferred int64
	ObjectsTotal       int64
	SpeedBytesPerSec   int64
	EtaSeconds         int64
	CurrentItem        string
}

// TailRcloneJSON tails an rclone JSON log file and emits normalized progress updates.
// It attempts to interpret common rclone JSON "stats" lines. Unknown lines are ignored.
func TailRcloneJSON(ctx context.Context, path string) (<-chan ProgressUpdate, <-chan error) {
	out := make(chan ProgressUpdate, 32)
	errCh := make(chan error, 1)

	go func() {
		defer close(out)
		defer close(errCh)
		t, err := tail.TailFile(path, tail.Config{
			Follow:   true,
			ReOpen:   true,
			MustExist: false,
			Logger:   tail.DiscardingLogger,
		})
		if err != nil {
			errCh <- fmt.Errorf("tail log: %w", err)
			return
		}
		defer t.Cleanup()

		for {
			select {
			case <-ctx.Done():
				return
			case line, ok := <-t.Lines:
				if !ok || line == nil {
					time.Sleep(200 * time.Millisecond)
					continue
				}
				var m map[string]any
				if err := json.Unmarshal([]byte(line.Text), &m); err != nil {
					continue
				}
				// Normalize probable stats line
				u := ProgressUpdate{}
				// rclone often uses "stats" for periodic updates
				if statsV, ok := m["stats"]; ok {
					if stats, ok := statsV.(map[string]any); ok {
						u.BytesTransferred = asInt64(stats["bytes"])
						u.BytesTotal = asInt64(stats["bytesTotal"])
						u.ObjectsTransferred = asInt64(stats["files"])
						u.ObjectsTotal = asInt64(stats["filesTotal"])
						u.SpeedBytesPerSec = asInt64(stats["speed"])
						u.EtaSeconds = asInt64(stats["eta"])
						if pct, ok := stats["percent"]; ok {
							u.ProgressPct = asFloat64(pct)
						} else {
							u.ProgressPct = percent(u.BytesTransferred, u.BytesTotal)
						}
						// Some lines report "lastTransferred"
						if last, ok := stats["lastTransferred"]; ok {
							u.CurrentItem = asString(last)
						}
						out <- u
						continue
					}
				}
				// Fallback: try top-level fields
				u.BytesTransferred = asInt64(m["bytes"])
				u.BytesTotal = asInt64(m["bytesTotal"])
				u.ObjectsTransferred = asInt64(m["files"])
				u.ObjectsTotal = asInt64(m["filesTotal"])
				u.SpeedBytesPerSec = asInt64(m["speed"])
				u.EtaSeconds = asInt64(m["eta"])
				if u.BytesTransferred > 0 || u.ObjectsTransferred > 0 {
					u.ProgressPct = percent(u.BytesTransferred, u.BytesTotal)
					out <- u
				}
			}
		}
	}()
	return out, errCh
}

func asInt64(v any) int64 {
	switch x := v.(type) {
	case nil:
		return 0
	case float64:
		return int64(x)
	case float32:
		return int64(x)
	case int64:
		return x
	case int:
		return int64(x)
	case string:
		if x == "" {
			return 0
		}
		if strings.Contains(x, ".") {
			f, _ := strconv.ParseFloat(x, 64)
			return int64(f)
		}
		i, _ := strconv.ParseInt(x, 10, 64)
		return i
	default:
		return 0
	}
}

func asFloat64(v any) float64 {
	switch x := v.(type) {
	case nil:
		return 0
	case float64:
		return x
	case float32:
		return float64(x)
	case int64:
		return float64(x)
	case int:
		return float64(x)
	case string:
		f, _ := strconv.ParseFloat(x, 64)
		return f
	default:
		return 0
	}
}

func asString(v any) string {
	switch x := v.(type) {
	case nil:
		return ""
	case string:
		return x
	default:
		b, _ := json.Marshal(x)
		return string(b)
	}
}

func percent(n, d int64) float64 {
	if d <= 0 {
		return 0
	}
	return (float64(n) / float64(d)) * 100.0
}


