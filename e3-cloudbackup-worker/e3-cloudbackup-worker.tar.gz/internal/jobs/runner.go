package jobs

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"time"

	"github.com/your-org/e3-cloudbackup-worker/internal/config"
	"github.com/your-org/e3-cloudbackup-worker/internal/crypto"
	"github.com/your-org/e3-cloudbackup-worker/internal/db"
	"github.com/your-org/e3-cloudbackup-worker/internal/logs"
	"github.com/your-org/e3-cloudbackup-worker/internal/rclone"
)

type Runner struct {
	db     *db.Database
	cfg    *config.Config
	rclone *rclone.Builder
}

func NewRunner(database *db.Database, cfg *config.Config) *Runner {
	return &Runner{
		db:     database,
		cfg:    cfg,
		rclone: rclone.NewBuilder(cfg),
	}
}

func (r *Runner) Run(ctx context.Context, run db.Run) error {
	job, err := r.db.GetJobConfig(ctx, run.JobID)
	if err != nil {
		now := time.Now().UTC()
		_ = r.db.UpdateRunStatus(ctx, run.ID, "failed", nil, &now, fmt.Sprintf("failed to load job config: %v", err))
		return fmt.Errorf("get job config: %w", err)
	}

	// Verify rclone binary exists
	if _, err := os.Stat(r.cfg.Rclone.BinaryPath); os.IsNotExist(err) {
		now := time.Now().UTC()
		_ = r.db.UpdateRunStatus(ctx, run.ID, "failed", nil, &now, fmt.Sprintf("rclone binary not found at %s", r.cfg.Rclone.BinaryPath))
		return fmt.Errorf("rclone binary not found: %s", r.cfg.Rclone.BinaryPath)
	}

	// Prepare working directory
	runDir := filepath.Join(r.cfg.Rclone.RunDir, fmt.Sprintf("%d", run.ID))
	if err := os.MkdirAll(runDir, 0o755); err != nil {
		now := time.Now().UTC()
		_ = r.db.UpdateRunStatus(ctx, run.ID, "failed", nil, &now, fmt.Sprintf("failed to create run directory: %v", err))
		return fmt.Errorf("create run dir: %w", err)
	}
	confPath := filepath.Join(runDir, "rclone.conf")
	logPath := filepath.Join(runDir, "rclone.json")

	// Decrypt source_config_enc
	decryptedSource, err := r.decryptSourceConfig(job.SourceConfigEnc)
	if err != nil {
		now := time.Now().UTC()
		_ = r.db.UpdateRunStatus(ctx, run.ID, "failed", nil, &now, "decrypt source config failed")
		return fmt.Errorf("decrypt source config: %w", err)
	}

	// Decrypt destination credentials
	decryptedDestAccessKey, err := r.decryptSourceConfig(job.DestAccessKeyEnc)
	if err != nil {
		now := time.Now().UTC()
		_ = r.db.UpdateRunStatus(ctx, run.ID, "failed", nil, &now, "decrypt destination access key failed")
		return fmt.Errorf("decrypt destination access key: %w", err)
	}

	decryptedDestSecretKey, err := r.decryptSourceConfig(job.DestSecretKeyEnc)
	if err != nil {
		now := time.Now().UTC()
		_ = r.db.UpdateRunStatus(ctx, run.ID, "failed", nil, &now, "decrypt destination secret key failed")
		return fmt.Errorf("decrypt destination secret key: %w", err)
	}

	// Write rclone config
	if _, _, err := r.rclone.GenerateRcloneConfig(ctx, job, confPath, decryptedSource, decryptedDestAccessKey, decryptedDestSecretKey); err != nil {
		now := time.Now().UTC()
		_ = r.db.UpdateRunStatus(ctx, run.ID, "failed", nil, &now, "write rclone config failed")
		return fmt.Errorf("generate rclone config: %w", err)
	}

	// Build command
	sourceRemote := "source"
	destRemote := "dest"
	args := r.rclone.BuildSyncArgs(job, sourceRemote, destRemote, confPath, logPath)
	cmd := exec.CommandContext(ctx, r.cfg.Rclone.BinaryPath, args...)
	cmd.Dir = runDir
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr

	started := time.Now().UTC()
	if err := r.db.UpdateRunStatus(ctx, run.ID, "starting", &started, nil, ""); err != nil {
		log.Printf("warning: failed to mark run starting: %v", err)
	}

	if err := cmd.Start(); err != nil {
		now := time.Now().UTC()
		_ = r.db.UpdateRunStatus(ctx, run.ID, "failed", nil, &now, "failed to start rclone")
		return fmt.Errorf("start rclone: %w", err)
	}

	// Mark as running after successful start
	if err := r.db.UpdateRunStatus(ctx, run.ID, "running", &started, nil, ""); err != nil {
		log.Printf("warning: failed to mark run running: %v", err)
	}

	// Ensure log directory exists
	if err := os.MkdirAll(filepath.Dir(logPath), 0o755); err != nil {
		log.Printf("warning: failed to create log directory: %v", err)
	}

	// Tail JSON log and update DB periodically
	progressCh, errCh := logs.TailRcloneJSON(ctx, logPath)
	lastUpdate := time.Time{}
	updateEvery := 5 * time.Second
	cancelCheckEvery := 5 * time.Second
	lastCancelCheck := time.Time{}
	doneCh := make(chan error, 1)

	go func() {
		defer close(doneCh)
		doneCh <- cmd.Wait()
	}()

	var lastProgress logs.ProgressUpdate

loop:
	for {
		select {
		case <-ctx.Done():
			_ = r.terminate(cmd)
			break loop
		case perr := <-errCh:
			if perr != nil {
				log.Printf("tail error: %v", perr)
			}
		case pu, ok := <-progressCh:
			if ok {
				lastProgress = pu
			}
			// Throttle DB updates
			if time.Since(lastUpdate) >= updateEvery && (lastProgress.BytesTransferred > 0 || lastProgress.ObjectsTransferred > 0) {
				_ = r.db.UpdateRunProgress(ctx, run.ID, db.Progress{
					ProgressPct:        lastProgress.ProgressPct,
					BytesTotal:         lastProgress.BytesTotal,
					BytesTransferred:   lastProgress.BytesTransferred,
					ObjectsTotal:       lastProgress.ObjectsTotal,
					ObjectsTransferred: lastProgress.ObjectsTransferred,
					SpeedBytesPerSec:   lastProgress.SpeedBytesPerSec,
					EtaSeconds:         lastProgress.EtaSeconds,
					CurrentItem:        lastProgress.CurrentItem,
				})
				lastUpdate = time.Now()
			}
		case err := <-doneCh:
			// rclone exited
			// Write log excerpt
			excerpt := readLastNLines(logPath, 200)
			now := time.Now().UTC()
			_ = r.db.UpdateRunLogPathAndExcerpt(ctx, run.ID, logPath, excerpt)
			
			if err != nil {
				// Check if it was a cancellation
				cancelRequested, _ := r.db.CheckCancelRequested(ctx, run.ID)
				if cancelRequested {
					_ = r.db.UpdateRunStatus(ctx, run.ID, "cancelled", nil, &now, "Job cancelled by user")
				} else {
					// Determine if it's a warning (partial transfer) or failure
					// Check if any data was transferred
					if lastProgress.BytesTransferred > 0 && lastProgress.BytesTransferred < lastProgress.BytesTotal {
						_ = r.db.UpdateRunStatus(ctx, run.ID, "warning", nil, &now, fmt.Sprintf("rclone exited with error but partial transfer completed: %v", err))
					} else {
						_ = r.db.UpdateRunStatus(ctx, run.ID, "failed", nil, &now, fmt.Sprintf("rclone failed: %v", err))
					}
				}
			} else {
				// Success - check if it was a partial transfer (warning)
				if lastProgress.BytesTotal > 0 && lastProgress.BytesTransferred < lastProgress.BytesTotal {
					_ = r.db.UpdateRunStatus(ctx, run.ID, "warning", nil, &now, "Transfer completed but not all files were transferred")
				} else {
					_ = r.db.UpdateRunStatus(ctx, run.ID, "success", nil, &now, "")
				}
			}
			break loop
		default:
			// Poll cancel flag periodically
			if time.Since(lastCancelCheck) >= cancelCheckEvery {
				cancel, cerr := r.db.CheckCancelRequested(ctx, run.ID)
				if cerr == nil && cancel {
					log.Printf("run %d: cancellation requested, terminating rclone", run.ID)
					if err := r.terminate(cmd); err != nil {
						log.Printf("run %d: error terminating rclone: %v", run.ID, err)
					}
					// Wait a bit for graceful shutdown, then kill if needed
					time.Sleep(5 * time.Second)
					if cmd.Process != nil && cmd.ProcessState == nil {
						log.Printf("run %d: force killing rclone", run.ID)
						_ = cmd.Process.Kill()
					}
				}
				lastCancelCheck = time.Now()
			}
			time.Sleep(100 * time.Millisecond)
		}
	}

	return nil
}

func (r *Runner) terminate(cmd *exec.Cmd) error {
	// Send SIGTERM on unix, kill on windows
	if cmd.Process == nil {
		return fmt.Errorf("process not started")
	}
	if runtime.GOOS == "windows" {
		return cmd.Process.Kill()
	}
	// Try graceful shutdown first
	if err := cmd.Process.Signal(syscall.SIGTERM); err != nil {
		return fmt.Errorf("send SIGTERM: %w", err)
	}
	return nil
}

// decryptSourceConfig decrypts the JSON payload stored in source_config_enc.
// Uses AES-256-CBC matching PHP HelperController::decryptKey() implementation.
func (r *Runner) decryptSourceConfig(enc string) (string, error) {
	key := config.GetEncryptionKey()
	if key == "" {
		return "", errors.New("CLOUD_BACKUP_ENCRYPTION_KEY not set")
	}

	// Handle plaintext JSON for testing (if data starts with { and ends with })
	trim := strings.TrimSpace(enc)
	if strings.HasPrefix(trim, "{") && strings.HasSuffix(trim, "}") && !strings.Contains(trim, "=") {
		// Likely plaintext JSON, return as-is
		return trim, nil
	}

	// Decrypt using AES-256-CBC
	decrypted, err := crypto.DecryptAES256CBC(enc, key)
	if err != nil {
		return "", fmt.Errorf("decrypt failed: %w", err)
	}

	return decrypted, nil
}

func readLastNLines(path string, n int) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()
	// Simple forward scan; acceptable for moderate log sizes
	var lines []string
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		lines = append(lines, sc.Text())
		if len(lines) > n {
			lines = lines[1:]
		}
	}
	if len(lines) == 0 {
		return ""
	}
	b, _ := json.MarshalIndent(lines, "", "  ")
	return string(b)
}


